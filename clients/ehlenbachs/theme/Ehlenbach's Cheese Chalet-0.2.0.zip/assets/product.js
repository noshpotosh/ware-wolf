(() => {
  const variantSelect = document.querySelector('.product-form select');
  const currentPrice = document.querySelector(
    '[data-product-current-price]'
  );
  const comparePrice = document.querySelector(
    '[data-product-compare-price]'
  );
  const submitButton = document.querySelector('.product-form__submit');

  function updateSelectedVariant() {
    if (!variantSelect || !currentPrice || !submitButton) return;

    const selectedOption = variantSelect.selectedOptions[0];
    const variantIsAvailable = selectedOption.dataset.available === 'true';

    currentPrice.textContent = selectedOption.dataset.price;
    submitButton.disabled = !variantIsAvailable;
    submitButton.textContent = variantIsAvailable
      ? 'Add to cart'
      : 'Sold out';

    if (!comparePrice) return;

    comparePrice.textContent = selectedOption.dataset.comparePrice;
    comparePrice.hidden = selectedOption.dataset.onSale !== 'true';
  }

  variantSelect?.addEventListener('change', updateSelectedVariant);

  const sections = document.querySelectorAll(
    '[data-product-recommendations]'
  );

  function loadRecommendations(section, observer) {
    observer.unobserve(section);

    fetch(section.dataset.url)
      .then((response) => response.text())
      .then((text) => {
        const responseDocument = new DOMParser().parseFromString(
          text,
          'text/html'
        );
        const recommendations = responseDocument.querySelector(
          '[data-product-recommendations]'
        );

        if (!recommendations?.innerHTML.trim()) return;

        section.innerHTML = recommendations.innerHTML;
      })
      .catch(() => {
        section.hidden = true;
      });
  }

  sections.forEach((section) => {
    const observer = new IntersectionObserver((entries) => {
      if (!entries[0].isIntersecting) return;

      loadRecommendations(section, observer);
    }, { rootMargin: '0px 0px 240px 0px' });

    observer.observe(section);
  });
})();
